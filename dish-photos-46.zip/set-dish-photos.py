#!/usr/bin/env python3
# Safe Deli - set dish photos (46 dishes). Run ONCE on the server.
# 1) backs up the DB, 2) sets home_dishes.image_url for the 46 dish ids,
#    ONLY where image_url is empty (never overwrites a real photo),
# 3) verifies every photo file exists, 4) prints a count + samples.
import os, shutil, sqlite3, sys, datetime

DB = "/root/safedeli/SAFE-DEIL/orders.db"
MEDIA = "/root/safedeli/media/product"
BASE = "https://safedeli.net/media/product/dish-photo-%d.jpg"

IDS = [21,25,71,22,23,24,69,72,74,32,33,34,26,30,31,44,
       45,46,47,48,49,50,51,52,53,58,59,60,61,62,63,64,
       65,66,67,68,76,27,28,29,54,55,56,57,70,73]

if not os.path.exists(DB):
    print("DB NOT FOUND:", DB); sys.exit(1)

bak = DB + ".bak-dishphotos-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
shutil.copy2(DB, bak)
print("backup:", bak)

con = sqlite3.connect(DB)
cur = con.cursor()
updated, skipped, missing = 0, 0, []
for did in IDS:
    fn = os.path.join(MEDIA, "dish-photo-%d.jpg" % did)
    if not os.path.exists(fn):
        missing.append(did); continue
    row = cur.execute("SELECT image_url FROM home_dishes WHERE id=?", (did,)).fetchone()
    if row is None:
        print("NO DISH id", did); continue
    if row[0]:
        print("SKIP id", did, "(already has photo)"); skipped += 1; continue
    cur.execute("UPDATE home_dishes SET image_url=? WHERE id=?", (BASE % did, did))
    updated += 1
con.commit()
print("updated:", updated, "| skipped (had photo):", skipped, "| missing files:", missing)
for did in IDS[:3]:
    print("sample:", cur.execute("SELECT id, name, image_url FROM home_dishes WHERE id=?", (did,)).fetchone())
print("total with photos now:", cur.execute("SELECT COUNT(*) FROM home_dishes WHERE image_url IS NOT NULL AND image_url<>''").fetchone()[0], "of", cur.execute("SELECT COUNT(*) FROM home_dishes").fetchone()[0])
con.close()
print("DONE")
