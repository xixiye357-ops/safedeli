#!/usr/bin/env python3
"""Seed the 20 real home dishes into the server database (run ONCE on
the server, as root, after the new api.py is deployed — the script also
creates the home_dishes table itself if it is missing, so the order
does not matter).

What it does:
  1. Backs up orders.db (orders.db.bak-seed-<timestamp>).
  2. For each dish in manifest.json: if a home_dishes row with the same
     name already exists, it is SKIPPED (re-running is safe); otherwise
     the photo is copied to <media>/product/<random-hex>.<ext> and a
     row is inserted (available, in manifest order).
  3. Prints SKIP/INSERT per dish + a final count.

Photo URLs use the same rule as the API: SAFEDELI_PUBLIC_BASE_URL
or https://safedeli.duckdns.org. Media dir: SAFEDELI_MEDIA_DIR or
the media/ folder next to orders.db.

Usage (on the server, in the unzipped folder):
  python3 seed-home-dishes.py
  python3 seed-home-dishes.py --db /root/safedeli/SAFE-DEIL/orders.db
"""
import argparse, json, os, secrets, shutil, sqlite3, sys
from datetime import datetime, timezone
from pathlib import Path

DDL = """CREATE TABLE IF NOT EXISTS home_dishes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT,
  price REAL CHECK(price IS NULL OR price>=0), currency TEXT NOT NULL DEFAULT 'THB',
  image_url TEXT, category TEXT NOT NULL, glyph TEXT NOT NULL DEFAULT 'bowl',
  unit TEXT NOT NULL DEFAULT '၁ ပွဲ', sort_order INTEGER NOT NULL DEFAULT 0,
  is_available INTEGER NOT NULL DEFAULT 1 CHECK(is_available IN (0,1)),
  created_at TEXT NOT NULL, updated_at TEXT)"""

HERE = Path(__file__).resolve().parent


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="/root/safedeli/SAFE-DEIL/orders.db")
    ap.add_argument("--photos-dir", default=str(HERE / "photos"))
    ap.add_argument("--manifest", default=str(HERE / "manifest.json"))
    args = ap.parse_args()
    db = Path(args.db)
    if not db.exists():
        print("ERROR: database not found: %s" % db)
        return 1
    manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    dishes = manifest["dishes"]
    media_dir = Path(os.environ.get("SAFEDELI_MEDIA_DIR") or "").expanduser() \
        if os.environ.get("SAFEDELI_MEDIA_DIR", "").strip() else db.parent / "media"
    base_url = (os.environ.get("SAFEDELI_PUBLIC_BASE_URL") or "https://safedeli.duckdns.org").rstrip("/")
    product_dir = media_dir / "product"
    product_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    backup = db.with_name(db.name + ".bak-seed-" + stamp)
    shutil.copy(db, backup)
    print("backup: %s" % backup)
    print("media dir: %s" % product_dir)
    print("base url: %s" % base_url)
    con = sqlite3.connect(db)
    con.execute(DDL)
    con.execute("PRAGMA foreign_keys=ON")
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    inserted, skipped = 0, 0
    for d in dishes:
        exists = con.execute("SELECT id FROM home_dishes WHERE name=?", (d["name"],)).fetchone()
        if exists:
            print("SKIP  %s (already row id %s)" % (d["name"], exists[0]))
            skipped += 1
            continue
        src = Path(args.photos_dir) / d["file"]
        if not src.exists():
            print("ERROR: photo missing: %s" % src)
            con.close()
            return 1
        ext = src.suffix.lstrip(".") or "jpg"
        name = secrets.token_hex(16) + "." + ext
        shutil.copy(src, product_dir / name)
        url = base_url + "/media/product/" + name
        con.execute(
            "INSERT INTO home_dishes(name,description,price,currency,image_url,category,glyph,unit,sort_order,is_available,created_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,1,?)",
            (d["name"], None, d["price"], d.get("currency", "THB"), url,
             d["category"], d["glyph"], d["unit"], d["sort_order"], now))
        print("INSERT %s -> %s" % (d["name"], url))
        inserted += 1
    con.commit()
    total = con.execute("SELECT COUNT(*) FROM home_dishes").fetchone()[0]
    con.close()
    print("done: %d inserted, %d skipped, %d home dishes in total" % (inserted, skipped, total))
    return 0


if __name__ == "__main__":
    sys.exit(main())
